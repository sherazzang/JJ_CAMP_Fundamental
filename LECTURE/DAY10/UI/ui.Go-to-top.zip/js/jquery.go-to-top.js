/*! jquery.go-to-top.js © yamoo9.net, 2017 */

/*
  설정할 class 속성
  ------------------
  .y9-is-visible
  .y9-fade-out
*/

