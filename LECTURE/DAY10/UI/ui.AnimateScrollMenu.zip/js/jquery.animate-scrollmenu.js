/*! jquery.animate-scrollmenu.js © yamoo9.net, 2017 */
